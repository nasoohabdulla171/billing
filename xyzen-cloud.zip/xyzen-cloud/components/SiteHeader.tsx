"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, Terminal } from "lucide-react";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/billing", label: "Billing" },
  { href: "/dashboard", label: "Dashboard" },
  { href: "/dashboard/orders", label: "My Orders" },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-line/60 bg-base/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link href="/" className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-signal/15 text-signal">
            <Terminal size={18} strokeWidth={2.25} />
          </span>
          XYZEN<span className="text-signal">CLOUD</span>
        </Link>

        <nav className="hidden items-center gap-7 font-mono text-[13px] text-white/60 md:flex">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="transition hover:text-white focus-ring rounded">
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <a
            href="https://panel.xyzencloud.online/"
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-line px-4 py-2 text-sm font-medium text-white/80 transition hover:border-signal/60 hover:text-white focus-ring"
          >
            Panel Login
          </a>
          <Link
            href="/billing"
            className="rounded-lg bg-signal px-4 py-2 text-sm font-semibold text-white shadow-[0_0_20px_-4px_rgba(124,92,255,0.7)] transition hover:bg-signal/90 focus-ring"
          >
            Get Started
          </Link>
        </div>

        <button
          className="text-white/80 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line/60 px-5 py-4 md:hidden">
          <nav className="flex flex-col gap-4 font-mono text-sm text-white/70">
            {LINKS.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
            <a href="https://panel.xyzencloud.online/" target="_blank" rel="noreferrer">
              Panel Login
            </a>
            <Link
              href="/billing"
              onClick={() => setOpen(false)}
              className="mt-2 w-full rounded-lg bg-signal px-4 py-2.5 text-center font-semibold text-white"
            >
              Get Started
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
