"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import PasswordStrength, { passwordIsValid } from "@/components/PasswordStrength";
import type { Category, Plan } from "@/lib/plans";
import { createOrder } from "@/lib/orders";

const INPUT =
  "w-full rounded-lg border border-line bg-panel px-3.5 py-2.5 text-sm text-white placeholder:text-white/25 outline-none transition focus:border-signal";
const LABEL = "mb-1.5 block font-mono text-[11px] uppercase tracking-wide text-white/40";

export default function DetailsForm({
  category,
  plan,
  extraOptionLabel,
}: {
  category: Category;
  plan: Plan;
  extraOptionLabel?: string;
}) {
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: "", lastName: "", username: "", email: "", phone: "",
    discordUsername: "", country: "", state: "", city: "", serverName: "",
    os: "", notes: "", password: "", confirmPassword: "",
  });
  const [agree, setAgree] = useState(false);
  const [error, setError] = useState("");

  function set<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const required: (keyof typeof form)[] = [
      "firstName", "lastName", "username", "email", "discordUsername",
      "country", "state", "city", "serverName",
    ];
    for (const key of required) {
      if (!form[key].trim()) {
        setError("Please fill in all required fields.");
        return;
      }
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      setError("Enter a valid email address.");
      return;
    }
    if (!passwordIsValid(form.password)) {
      setError("Your password doesn't meet the strength requirements yet.");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords don't match.");
      return;
    }
    if (!agree) {
      setError("You need to agree to the Terms to continue.");
      return;
    }

    const order = createOrder({
      categoryId: category.id,
      categoryName: category.name,
      planId: plan.id,
      planName: plan.name,
      price: plan.price,
      extraOptionLabel,
      firstName: form.firstName,
      lastName: form.lastName,
      username: form.username,
      email: form.email,
      phone: form.phone || undefined,
      discordUsername: form.discordUsername,
      country: form.country,
      state: form.state,
      city: form.city,
      serverName: form.serverName,
      os: form.os || undefined,
      notes: form.notes || undefined,
    });

    router.push(`/billing/${category.id}/${plan.id}/payment?order=${order.id}`);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <fieldset className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className={LABEL}>First name *</label>
          <input className={INPUT} value={form.firstName} onChange={(e) => set("firstName", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Last name *</label>
          <input className={INPUT} value={form.lastName} onChange={(e) => set("lastName", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Username *</label>
          <input className={INPUT} value={form.username} onChange={(e) => set("username", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Email address *</label>
          <input type="email" className={INPUT} value={form.email} onChange={(e) => set("email", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Phone number (optional)</label>
          <input className={INPUT} value={form.phone} onChange={(e) => set("phone", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Discord username *</label>
          <input className={INPUT} placeholder="yourname" value={form.discordUsername} onChange={(e) => set("discordUsername", e.target.value)} />
        </div>
      </fieldset>

      <fieldset className="grid gap-5 sm:grid-cols-3">
        <div>
          <label className={LABEL}>Country *</label>
          <input className={INPUT} value={form.country} onChange={(e) => set("country", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>State *</label>
          <input className={INPUT} value={form.state} onChange={(e) => set("state", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>City *</label>
          <input className={INPUT} value={form.city} onChange={(e) => set("city", e.target.value)} />
        </div>
      </fieldset>

      <fieldset className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className={LABEL}>Server name *</label>
          <input className={INPUT} placeholder="e.g. SkyWars Network" value={form.serverName} onChange={(e) => set("serverName", e.target.value)} />
        </div>
        <div>
          <label className={LABEL}>Operating system (optional)</label>
          <select className={INPUT} value={form.os} onChange={(e) => set("os", e.target.value)}>
            <option value="">Not applicable</option>
            <option value="linux">Linux</option>
            <option value="windows">Windows</option>
          </select>
        </div>
      </fieldset>

      <div>
        <label className={LABEL}>Notes (optional)</label>
        <textarea
          className={INPUT + " min-h-[80px] resize-y"}
          value={form.notes}
          onChange={(e) => set("notes", e.target.value)}
          placeholder="Anything we should know before setting this up?"
        />
      </div>

      <fieldset className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className={LABEL}>Strong password *</label>
          <input type="password" className={INPUT} value={form.password} onChange={(e) => set("password", e.target.value)} />
          <PasswordStrength password={form.password} />
        </div>
        <div>
          <label className={LABEL}>Confirm password *</label>
          <input type="password" className={INPUT} value={form.confirmPassword} onChange={(e) => set("confirmPassword", e.target.value)} />
        </div>
      </fieldset>

      <label className="flex items-start gap-2.5 text-sm text-white/60">
        <input
          type="checkbox"
          checked={agree}
          onChange={(e) => setAgree(e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-line bg-panel accent-signal"
        />
        I agree to the Terms of Service and understand my server will be provisioned after payment approval.
      </label>

      {error && (
        <p className="rounded-lg border border-danger/30 bg-danger/10 px-3.5 py-2.5 text-sm text-danger">
          {error}
        </p>
      )}

      <button
        type="submit"
        className="w-full rounded-lg bg-signal py-3 text-sm font-semibold text-white shadow-[0_0_25px_-6px_rgba(124,92,255,0.8)] transition hover:bg-signal/90 focus-ring sm:w-auto sm:px-8"
      >
        Continue to payment
      </button>
    </form>
  );
}
