"use client";

import { MessageCircle } from "lucide-react";

export default function FloatingSupport() {
  return (
    <a
      href="https://discord.gg/NpgkzC97zV"
      target="_blank"
      rel="noreferrer"
      className="group fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-panel-2 py-3 pl-3 pr-4 shadow-[0_8px_30px_-6px_rgba(0,0,0,0.6)] ring-1 ring-line transition hover:ring-signal/60 focus-ring"
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-signal/15 text-signal">
        <MessageCircle size={16} />
      </span>
      <span className="font-mono text-xs text-white/80 group-hover:text-white">
        Support on Discord
      </span>
      <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-mint ring-2 ring-panel-2" />
    </a>
  );
}
