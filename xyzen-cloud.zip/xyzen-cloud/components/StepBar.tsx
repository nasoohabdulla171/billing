const STEPS = ["Category", "Plan", "Options", "Details", "Payment"];

export default function StepBar({ current }: { current: number }) {
  return (
    <div className="mb-8 flex items-center gap-2 font-mono text-[11px] text-white/40">
      {STEPS.map((s, i) => (
        <div key={s} className="flex items-center gap-2">
          <span
            className={
              i + 1 === current
                ? "flex h-5 w-5 items-center justify-center rounded-full bg-signal text-white"
                : i + 1 < current
                ? "flex h-5 w-5 items-center justify-center rounded-full bg-mint/20 text-mint"
                : "flex h-5 w-5 items-center justify-center rounded-full border border-line text-white/30"
            }
          >
            {i + 1}
          </span>
          <span className={i + 1 === current ? "text-white" : ""}>{s}</span>
          {i < STEPS.length - 1 && <span className="mx-1 text-white/20">/</span>}
        </div>
      ))}
    </div>
  );
}
