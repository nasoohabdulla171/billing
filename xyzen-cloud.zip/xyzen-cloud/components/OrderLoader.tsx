"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getOrder, type Order } from "@/lib/orders";
import PaymentClient from "@/components/PaymentClient";

export default function OrderLoader({ orderId }: { orderId: string }) {
  const [order, setOrder] = useState<Order | null | undefined>(undefined);

  useEffect(() => {
    setOrder(getOrder(orderId) ?? null);
  }, [orderId]);

  if (order === undefined) {
    return <p className="font-mono text-sm text-white/40">Loading order…</p>;
  }

  if (order === null) {
    return (
      <div className="rounded-xl border border-line bg-panel p-8 text-center">
        <p className="text-white/70">We couldn't find that order on this device.</p>
        <p className="mt-1 text-sm text-white/40">
          Orders are tied to the browser they were created in during this preview.
        </p>
        <Link href="/billing" className="mt-4 inline-block text-signal hover:underline">
          Start a new order
        </Link>
      </div>
    );
  }

  return <PaymentClient order={order} />;
}
