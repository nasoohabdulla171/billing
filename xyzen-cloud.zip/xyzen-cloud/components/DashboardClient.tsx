"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LayoutDashboard, Package, CreditCard, FileText, Settings, MessageCircle, ExternalLink, LogOut } from "lucide-react";
import { getAllOrders, type Order } from "@/lib/orders";
import StatusBadge from "@/components/StatusBadge";

const NAV = [
  { label: "Dashboard", icon: LayoutDashboard, href: "/dashboard" },
  { label: "Orders", icon: Package, href: "/dashboard/orders" },
  { label: "Billing", icon: CreditCard, href: "/billing" },
  { label: "Invoices", icon: FileText, href: "/dashboard/orders" },
  { label: "Settings", icon: Settings, href: "/dashboard" },
];

export default function DashboardClient() {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    setOrders(getAllOrders());
  }, []);

  const pending = orders.filter((o) => o.status === "pending").length;
  const approved = orders.filter((o) => o.status === "approved").length;
  const totalPaid = orders.filter((o) => o.status === "approved").reduce((s, o) => s + o.price, 0);

  return (
    <div className="mx-auto flex max-w-7xl gap-8 px-5 py-12">
      <aside className="hidden w-56 shrink-0 md:block">
        <nav className="sticky top-24 space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-white/60 transition hover:bg-panel hover:text-white"
            >
              <item.icon size={16} /> {item.label}
            </Link>
          ))}
          <a
            href="https://panel.xyzencloud.online/"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-white/60 transition hover:bg-panel hover:text-white"
          >
            <ExternalLink size={16} /> Panel
          </a>
          <a
            href="https://discord.gg/NpgkzC97zV"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-white/60 transition hover:bg-panel hover:text-white"
          >
            <MessageCircle size={16} /> Support
          </a>
          <button className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-white/40 transition hover:bg-panel hover:text-white">
            <LogOut size={16} /> Logout
          </button>
        </nav>
      </aside>

      <div className="flex-1">
        <h1 className="font-display text-2xl font-semibold text-white sm:text-3xl">Dashboard</h1>
        <p className="mt-1 text-white/50">Welcome back — here's what's happening with your servers.</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-4">
          <StatCard label="Active orders" value={orders.length} />
          <StatCard label="Pending" value={pending} accent="text-warn" />
          <StatCard label="Approved" value={approved} accent="text-mint" />
          <StatCard label="Total paid" value={`₹${totalPaid}`} />
        </div>

        <div className="mt-10 rounded-xl border border-line bg-panel/60">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <p className="font-mono text-xs uppercase tracking-widest text-signal">Recent orders</p>
            <Link href="/dashboard/orders" className="font-mono text-xs text-white/40 hover:text-white">
              View all →
            </Link>
          </div>

          {orders.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-white/50">No orders yet.</p>
              <Link href="/billing" className="mt-3 inline-block text-signal hover:underline">
                Start your first order
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-line">
              {orders.slice(0, 5).map((o) => (
                <Link
                  key={o.id}
                  href={`/dashboard/orders/${o.id}`}
                  className="flex items-center justify-between px-5 py-4 transition hover:bg-panel-2"
                >
                  <div>
                    <p className="font-mono text-sm text-white">{o.id}</p>
                    <p className="text-xs text-white/40">{o.categoryName} · {o.planName}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-mono text-sm text-white/70">₹{o.price}</span>
                    <StatusBadge status={o.status} />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string | number; accent?: string }) {
  return (
    <div className="rounded-xl border border-line bg-panel p-5">
      <p className="text-xs text-white/40">{label}</p>
      <p className={`mt-2 font-display text-2xl font-semibold ${accent ?? "text-white"}`}>{value}</p>
    </div>
  );
}
