"use client";

import { useEffect, useState } from "react";
import { Check, X } from "lucide-react";
import { getAllOrders, updateOrderStatus, type Order } from "@/lib/orders";
import StatusBadge from "@/components/StatusBadge";

const DECLINE_REASONS = [
  "Payment Not Received", "Wrong Amount", "Fake Screenshot", "Duplicate Order", "Other",
];

export default function AdminClient() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [declining, setDeclining] = useState<string | null>(null);
  const [reason, setReason] = useState(DECLINE_REASONS[0]);

  function refresh() {
    setOrders(getAllOrders());
  }

  useEffect(() => {
    refresh();
  }, []);

  function approve(id: string) {
    updateOrderStatus(id, "approved");
    refresh();
  }

  function confirmDecline(id: string) {
    updateOrderStatus(id, "declined", reason);
    setDeclining(null);
    refresh();
  }

  return (
    <section className="mx-auto max-w-5xl px-5 py-16">
      <p className="font-mono text-xs uppercase tracking-widest text-signal">Admin</p>
      <h1 className="mt-2 font-display text-3xl font-semibold text-white">Order approvals</h1>
      <p className="mt-2 text-white/60">
        This is the Phase 1 preview admin view — it approves/declines orders
        stored in this browser. Phase 2 replaces this with a real authenticated
        admin panel backed by the database and Discord bot.
      </p>

      <div className="mt-8 space-y-4">
        {orders.length === 0 && <p className="text-white/40">No orders yet.</p>}
        {orders.map((o) => (
          <div key={o.id} className="rounded-xl border border-line bg-panel p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-mono text-sm text-white">{o.id}</p>
                <p className="text-xs text-white/40">
                  {o.categoryName} · {o.planName} · {o.firstName} {o.lastName} · {o.email}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono text-sm text-white/70">₹{o.price}</span>
                <StatusBadge status={o.status} />
              </div>
            </div>

            {o.status === "pending" && (
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-4">
                <button
                  onClick={() => approve(o.id)}
                  className="flex items-center gap-1.5 rounded-lg bg-mint/15 px-3.5 py-1.5 text-xs font-medium text-mint transition hover:bg-mint/25"
                >
                  <Check size={13} /> Approve
                </button>
                {declining === o.id ? (
                  <div className="flex items-center gap-2">
                    <select
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      className="rounded-lg border border-line bg-base px-2 py-1.5 text-xs text-white"
                    >
                      {DECLINE_REASONS.map((r) => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                    <button
                      onClick={() => confirmDecline(o.id)}
                      className="rounded-lg bg-danger/15 px-3 py-1.5 text-xs font-medium text-danger hover:bg-danger/25"
                    >
                      Confirm decline
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setDeclining(o.id)}
                    className="flex items-center gap-1.5 rounded-lg bg-danger/15 px-3.5 py-1.5 text-xs font-medium text-danger transition hover:bg-danger/25"
                  >
                    <X size={13} /> Decline
                  </button>
                )}
              </div>
            )}

            {o.status === "declined" && o.declineReason && (
              <p className="mt-3 text-xs text-white/40">Declined: {o.declineReason}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
