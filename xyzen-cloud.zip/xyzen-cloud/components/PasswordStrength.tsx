"use client";

function scorePassword(pw: string): number {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score;
}

export function passwordIsValid(pw: string): boolean {
  return scorePassword(pw) >= 5;
}

export default function PasswordStrength({ password }: { password: string }) {
  const score = scorePassword(password);
  const label = ["Too weak", "Weak", "Weak", "Medium", "Strong", "Strong"][score];
  const color = [
    "bg-danger", "bg-danger", "bg-danger", "bg-warn", "bg-mint", "bg-mint",
  ][score];

  if (!password) return null;

  return (
    <div className="mt-2">
      <div className="flex gap-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <span
            key={i}
            className={`h-1 flex-1 rounded-full ${i < score ? color : "bg-line"}`}
          />
        ))}
      </div>
      <p className={`mt-1.5 font-mono text-[11px] ${score >= 5 ? "text-mint" : score >= 3 ? "text-warn" : "text-danger"}`}>
        {label} — needs 8+ characters, upper &amp; lowercase, a number, and a symbol.
      </p>
    </div>
  );
}
