"use client";

import { useEffect, useState } from "react";

const LINES = [
  { label: "node", value: "in-mum-04", color: "text-mint" },
  { label: "status", value: "online", color: "text-mint" },
  { label: "ddos_shield", value: "active", color: "text-signal-2" },
  { label: "avg_ping", value: "27ms", color: "text-white/70" },
  { label: "uptime_30d", value: "99.97%", color: "text-white/70" },
];

export default function ConsoleReadout() {
  const [visibleLines, setVisibleLines] = useState(0);
  const [players, setPlayers] = useState(1842);
  const [blink, setBlink] = useState(true);

  useEffect(() => {
    const t = setInterval(() => {
      setVisibleLines((n) => (n < LINES.length ? n + 1 : n));
    }, 220);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setInterval(() => {
      setPlayers((p) => p + Math.floor(Math.random() * 7 - 3));
    }, 1800);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setBlink((b) => !b), 550);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="w-full max-w-md rounded-xl border border-line bg-panel/80 backdrop-blur-sm shadow-[0_0_60px_-15px_rgba(124,92,255,0.35)]">
      <div className="flex items-center gap-1.5 border-b border-line px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-danger/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-warn/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-mint/70" />
        <span className="ml-2 font-mono text-[11px] text-white/40">xyzen@node ~ status</span>
      </div>
      <div className="space-y-1.5 p-4 font-mono text-[13px]">
        {LINES.slice(0, visibleLines).map((l) => (
          <div key={l.label} className="flex justify-between">
            <span className="text-white/40">{l.label}</span>
            <span className={l.color}>{l.value}</span>
          </div>
        ))}
        {visibleLines >= LINES.length && (
          <>
            <div className="flex justify-between font-mono-tabular">
              <span className="text-white/40">players_online</span>
              <span className="text-white">{players.toLocaleString()}</span>
            </div>
            <div className="pt-1 text-white/50">
              &gt; ready{blink ? "_" : " "}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
