import type { OrderStatus } from "@/lib/orders";

const STYLES: Record<OrderStatus, string> = {
  pending: "bg-warn/10 text-warn",
  approved: "bg-mint/10 text-mint",
  declined: "bg-danger/10 text-danger",
};

const DOT: Record<OrderStatus, string> = {
  pending: "bg-warn",
  approved: "bg-mint",
  declined: "bg-danger",
};

export default function StatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span className={`flex w-fit items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[11px] ${STYLES[status]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${DOT[status]}`} />
      {status}
    </span>
  );
}
