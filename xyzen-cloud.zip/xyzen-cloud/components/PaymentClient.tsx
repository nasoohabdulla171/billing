"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Copy, Check, ExternalLink, Download, MessageCircle, Upload, Loader2 } from "lucide-react";
import QRCode from "qrcode";
import type { Order } from "@/lib/orders";

const UPI_ID = "nasooh@fam";

export default function PaymentClient({ order }: { order: Order }) {
  const router = useRouter();
  const [qrUrl, setQrUrl] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(10 * 60);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [error, setError] = useState("");

  const upiUri = `upi://pay?pa=${UPI_ID}&pn=XYZEN%20CLOUD&am=${order.price}&cu=INR&tn=${order.id}`;

  useEffect(() => {
    QRCode.toDataURL(upiUri, {
      width: 320,
      margin: 1,
      color: { dark: "#0B0A10", light: "#FFFFFF" },
    }).then(setQrUrl);
  }, [upiUri]);

  useEffect(() => {
    const t = setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);

  function copyUpi() {
    navigator.clipboard.writeText(UPI_ID);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  async function markPaid() {
    setError("");
    if (!screenshot) {
      setError("Please attach a screenshot of your payment first.");
      return;
    }

    setSubmitting(true);
    try {
      const form = new FormData();
      form.append("orderId", order.id);
      form.append("categoryName", order.categoryName);
      form.append("planName", order.planName);
      form.append("price", String(order.price));
      if (order.extraOptionLabel) form.append("extraOptionLabel", order.extraOptionLabel);
      form.append("firstName", order.firstName);
      form.append("lastName", order.lastName);
      form.append("username", order.username);
      form.append("email", order.email);
      form.append("discordUsername", order.discordUsername);
      form.append("serverName", order.serverName);
      form.append("screenshot", screenshot);

      const res = await fetch("/api/orders/submit", { method: "POST", body: form });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Something went wrong submitting your payment.");
      }

      setSubmitted(true);
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Something went wrong. Please try again or contact support."
      );
    } finally {
      setSubmitting(false);
    }
  }

  const mins = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const secs = String(secondsLeft % 60).padStart(2, "0");

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
      <div className="rounded-xl border border-line bg-panel p-6 sm:p-8">
        <div className="flex items-center justify-between">
          <p className="font-mono text-xs uppercase tracking-widest text-signal">Scan to pay</p>
          <span className="flex items-center gap-1.5 rounded-full bg-warn/10 px-2.5 py-1 font-mono text-[11px] text-warn">
            <span className="h-1.5 w-1.5 rounded-full bg-warn" /> pending
          </span>
        </div>

        <div className="mt-6 flex justify-center">
          <div className="rounded-2xl bg-white p-4">
            {qrUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={qrUrl} alt="UPI payment QR code" width={280} height={280} />
            ) : (
              <div className="flex h-[280px] w-[280px] items-center justify-center text-black/30">
                Generating…
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 flex items-center justify-between rounded-lg border border-line bg-base px-4 py-3">
          <div>
            <p className="font-mono text-[11px] text-white/40">UPI ID</p>
            <p className="font-mono text-sm text-white">{UPI_ID}</p>
          </div>
          <button
            onClick={copyUpi}
            className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-xs text-white/70 transition hover:border-signal/60 hover:text-white focus-ring"
          >
            {copied ? <Check size={13} className="text-mint" /> : <Copy size={13} />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <a
            href={upiUri}
            className="flex items-center justify-center gap-1.5 rounded-lg border border-line py-2.5 text-xs text-white/70 transition hover:border-signal/60 hover:text-white"
          >
            <ExternalLink size={13} /> Open UPI App
          </a>
          <a
            href={qrUrl}
            download={`xyzen-payment-${order.id}.png`}
            className="flex items-center justify-center gap-1.5 rounded-lg border border-line py-2.5 text-xs text-white/70 transition hover:border-signal/60 hover:text-white"
          >
            <Download size={13} /> Download QR
          </a>
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-line pt-6">
          <div>
            <p className="text-xs text-white/40">Amount</p>
            <p className="font-display text-2xl font-semibold text-white">₹{order.price}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-white/40">Time remaining</p>
            <p className="font-mono-tabular font-mono text-lg text-white">{mins}:{secs}</p>
          </div>
        </div>

        {!submitted && (
          <div className="mt-6 border-t border-line pt-6">
            <label className={"mb-1.5 block font-mono text-[11px] uppercase tracking-wide text-white/40"}>
              Payment screenshot *
            </label>
            <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-dashed border-line bg-base px-4 py-3.5 text-sm text-white/60 transition hover:border-signal/50">
              <Upload size={16} className="shrink-0 text-signal" />
              {screenshot ? screenshot.name : "Attach a screenshot of your UPI payment"}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => setScreenshot(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>
        )}

        {error && (
          <p className="mt-4 rounded-lg border border-danger/30 bg-danger/10 px-3.5 py-2.5 text-sm text-danger">
            {error}
          </p>
        )}

        {!submitted ? (
          <button
            onClick={markPaid}
            disabled={submitting}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-signal py-3.5 text-sm font-semibold text-white shadow-[0_0_25px_-6px_rgba(124,92,255,0.8)] transition hover:bg-signal/90 disabled:opacity-60 focus-ring"
          >
            {submitting && <Loader2 size={16} className="animate-spin" />}
            {submitting ? "Submitting…" : "I HAVE COMPLETED PAYMENT"}
          </button>
        ) : (
          <div className="mt-6 space-y-4 rounded-lg border border-mint/30 bg-mint/5 p-5">
            <p className="font-display text-base font-semibold text-white">Thank you 🎉</p>
            <p className="text-sm text-white/60">
              Your payment request has been submitted. Please wait approximately
              10 minutes while our team reviews it — you'll get an email the
              moment it's approved.
            </p>
            <div className="flex flex-wrap gap-3 pt-1">
              <button
                onClick={() => router.push(`/dashboard/orders/${order.id}`)}
                className="rounded-lg bg-signal px-4 py-2 text-xs font-semibold text-white"
              >
                Track this order
              </button>
              <a
                href="https://discord.gg/NpgkzC97zV"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 rounded-lg border border-line px-4 py-2 text-xs text-white/70 hover:text-white"
              >
                <MessageCircle size={13} /> Create a support ticket
              </a>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div className="rounded-xl border border-line bg-panel/70 p-6">
          <p className="font-mono text-xs uppercase tracking-widest text-signal">Order</p>
          <p className="mt-3 font-mono text-sm text-white/70">
            ID <span className="text-white">{order.id}</span>
          </p>
          <p className="mt-1 text-sm text-white/50">{order.categoryName} · {order.planName}</p>
          <p className="mt-1 text-sm text-white/50">Server: {order.serverName}</p>
        </div>
        <div className="rounded-xl border border-line bg-panel/70 p-6 text-sm text-white/50">
          <p className="mb-2 font-medium text-white/80">Need help?</p>
          <p>
            If the QR doesn't work or you're unsure about anything, open a
            ticket on our Discord and our team will help directly.
          </p>
          <a
            href="https://discord.gg/NpgkzC97zV"
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 text-signal hover:underline"
          >
            <MessageCircle size={13} /> discord.gg/NpgkzC97zV
          </a>
        </div>
      </div>
    </div>
  );
}
