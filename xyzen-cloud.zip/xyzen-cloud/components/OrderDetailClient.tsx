"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Clock, CheckCircle2, XCircle, ExternalLink, MessageCircle } from "lucide-react";
import { getOrder, type Order } from "@/lib/orders";
import StatusBadge from "@/components/StatusBadge";

export default function OrderDetailClient({ orderId }: { orderId: string }) {
  const [order, setOrder] = useState<Order | null | undefined>(undefined);

  useEffect(() => {
    setOrder(getOrder(orderId) ?? null);
  }, [orderId]);

  if (order === undefined) {
    return <p className="p-16 text-center font-mono text-sm text-white/40">Loading…</p>;
  }

  if (order === null) {
    return (
      <div className="mx-auto max-w-2xl px-5 py-16 text-center">
        <p className="text-white/70">Order not found on this device.</p>
        <Link href="/dashboard/orders" className="mt-3 inline-block text-signal hover:underline">
          Back to orders
        </Link>
      </div>
    );
  }

  return (
    <section className="mx-auto max-w-3xl px-5 py-16">
      <Link href="/dashboard/orders" className="font-mono text-xs text-white/40 hover:text-white">
        ← All orders
      </Link>

      <div className="mt-4 flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-white sm:text-3xl">{order.id}</h1>
        <StatusBadge status={order.status} />
      </div>
      <p className="mt-1 text-white/50">{order.categoryName} · {order.planName}</p>

      {/* status timeline */}
      <div className="mt-8 rounded-xl border border-line bg-panel/60 p-6">
        {order.status === "pending" && (
          <div className="flex items-start gap-3">
            <Clock size={20} className="mt-0.5 shrink-0 text-warn" />
            <div>
              <p className="font-medium text-white">Waiting for approval</p>
              <p className="mt-1 text-sm text-white/50">
                Our team reviews payments within ~10 minutes. You'll get an
                email at <span className="text-white/80">{order.email}</span> the
                moment this is approved.
              </p>
            </div>
          </div>
        )}
        {order.status === "approved" && (
          <div className="flex items-start gap-3">
            <CheckCircle2 size={20} className="mt-0.5 shrink-0 text-mint" />
            <div>
              <p className="font-medium text-white">Order approved</p>
              <p className="mt-1 text-sm text-white/50">
                Your server is provisioned. Access it from the hosting panel below.
              </p>
              <a
                href="https://panel.xyzencloud.online/"
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-signal px-4 py-2 text-xs font-semibold text-white"
              >
                <ExternalLink size={13} /> Open Hosting Panel
              </a>
            </div>
          </div>
        )}
        {order.status === "declined" && (
          <div className="flex items-start gap-3">
            <XCircle size={20} className="mt-0.5 shrink-0 text-danger" />
            <div>
              <p className="font-medium text-white">Order declined</p>
              {order.declineReason && (
                <p className="mt-1 text-sm text-white/50">Reason: {order.declineReason}</p>
              )}
              <a
                href="https://discord.gg/NpgkzC97zV"
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-line px-4 py-2 text-xs text-white/70 hover:text-white"
              >
                <MessageCircle size={13} /> Open a support ticket
              </a>
            </div>
          </div>
        )}
      </div>

      {/* order details */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <DetailCard title="Customer">
          <Row k="Name" v={`${order.firstName} ${order.lastName}`} />
          <Row k="Username" v={order.username} />
          <Row k="Email" v={order.email} />
          <Row k="Discord" v={order.discordUsername} />
          {order.phone && <Row k="Phone" v={order.phone} />}
        </DetailCard>
        <DetailCard title="Server">
          <Row k="Server name" v={order.serverName} />
          <Row k="Location" v={`${order.city}, ${order.state}, ${order.country}`} />
          {order.extraOptionLabel && <Row k="Option" v={order.extraOptionLabel} />}
          {order.os && <Row k="OS" v={order.os} />}
          <Row k="Price" v={`₹${order.price}/mo`} />
        </DetailCard>
      </div>
    </section>
  );
}

function DetailCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-line bg-panel p-5">
      <p className="font-mono text-xs uppercase tracking-widest text-signal">{title}</p>
      <div className="mt-3 space-y-2">{children}</div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-white/40">{k}</span>
      <span className="text-right text-white/80">{v}</span>
    </div>
  );
}
