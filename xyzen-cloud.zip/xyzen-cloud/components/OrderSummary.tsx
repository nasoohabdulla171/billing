import { ShieldCheck, Zap, MapPin } from "lucide-react";
import type { Category, Plan } from "@/lib/plans";

export default function OrderSummary({
  category,
  plan,
  extraOptionLabel,
}: {
  category: Category;
  plan: Plan;
  extraOptionLabel?: string;
}) {
  return (
    <div className="rounded-xl border border-line bg-panel/70 p-6">
      <p className="font-mono text-xs uppercase tracking-widest text-signal">Order summary</p>

      <div className="mt-4 space-y-1">
        <p className="font-display text-lg font-semibold text-white">{category.name}</p>
        <p className="text-sm text-white/50">{plan.name} plan{extraOptionLabel ? ` · ${extraOptionLabel}` : ""}</p>
      </div>

      <div className="mt-5 space-y-2 border-t border-line pt-5">
        {plan.specs.map((s) => (
          <div key={s.label} className="flex justify-between text-sm">
            <span className="text-white/40">{s.label}</span>
            <span className="font-mono text-white/80">{s.value}</span>
          </div>
        ))}
      </div>

      <div className="mt-5 space-y-2 border-t border-line pt-5 text-sm text-white/60">
        <div className="flex items-center gap-2"><MapPin size={13} className="text-signal" /> Node: India</div>
        <div className="flex items-center gap-2"><ShieldCheck size={13} className="text-signal" /> DDoS Protection: Enabled</div>
        <div className="flex items-center gap-2"><Zap size={13} className="text-signal" /> Setup: Instant after approval</div>
      </div>

      <div className="mt-5 flex items-baseline justify-between border-t border-line pt-5">
        <span className="text-sm text-white/50">Total / month</span>
        <span className="font-display text-2xl font-semibold text-white">₹{plan.price}</span>
      </div>

      <p className="mt-3 font-mono text-[11px] text-white/30">Estimated approval: ~10 minutes</p>
    </div>
  );
}
