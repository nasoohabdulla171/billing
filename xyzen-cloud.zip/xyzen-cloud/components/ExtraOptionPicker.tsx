"use client";

import { useRouter } from "next/navigation";
import { Check } from "lucide-react";
import type { ExtraOptionGroup } from "@/lib/plans";

export default function ExtraOptionPicker({
  option,
  categoryId,
  planId,
}: {
  option: ExtraOptionGroup;
  categoryId: string;
  planId: string;
}) {
  const router = useRouter();

  function choose(choiceId: string) {
    router.push(`/billing/${categoryId}/${planId}/details?opt=${choiceId}`);
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {option.choices.map((c) => (
        <button
          key={c.id}
          onClick={() => choose(c.id)}
          className="group flex items-center justify-between rounded-xl border border-line bg-panel p-6 text-left transition hover:border-signal/50 hover:bg-panel-2 focus-ring"
        >
          <div>
            <p className="font-display text-base font-semibold text-white">{c.label}</p>
            <p className="mt-1 text-xs text-white/40">{option.label}</p>
          </div>
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-white/30 transition group-hover:border-signal group-hover:bg-signal group-hover:text-white">
            <Check size={15} />
          </span>
        </button>
      ))}
    </div>
  );
}
