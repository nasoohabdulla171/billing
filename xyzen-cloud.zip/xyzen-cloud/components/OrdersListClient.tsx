"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getAllOrders, type Order, type OrderStatus } from "@/lib/orders";
import StatusBadge from "@/components/StatusBadge";

const FILTERS: { id: OrderStatus | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "pending", label: "Pending" },
  { id: "approved", label: "Approved" },
  { id: "declined", label: "Declined" },
];

export default function OrdersListClient() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<OrderStatus | "all">("all");

  useEffect(() => {
    setOrders(getAllOrders());
  }, []);

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  return (
    <section className="mx-auto max-w-5xl px-5 py-16">
      <h1 className="font-display text-3xl font-semibold text-white sm:text-4xl">My orders</h1>
      <p className="mt-2 text-white/60">Track approval status for every order you've placed.</p>

      <div className="mt-6 flex gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={
              "rounded-full px-3.5 py-1.5 font-mono text-xs transition " +
              (filter === f.id ? "bg-signal text-white" : "border border-line text-white/50 hover:text-white")
            }
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-8 overflow-hidden rounded-xl border border-line">
        {filtered.length === 0 ? (
          <div className="bg-panel/60 p-10 text-center">
            <p className="text-white/50">No orders in this category.</p>
            <Link href="/billing" className="mt-3 inline-block text-signal hover:underline">
              Start an order
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-line bg-panel/40">
            {filtered.map((o) => (
              <Link
                key={o.id}
                href={`/dashboard/orders/${o.id}`}
                className="flex flex-col gap-2 px-5 py-4 transition hover:bg-panel-2 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="font-mono text-sm text-white">{o.id}</p>
                  <p className="text-xs text-white/40">
                    {o.categoryName} · {o.planName} · {new Date(o.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-sm text-white/70">₹{o.price}/mo</span>
                  <StatusBadge status={o.status} />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
