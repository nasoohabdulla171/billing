# XYZEN CLOUD — Billing System

A full billing/order flow for XYZEN CLOUD hosting: category → plan →
options → customer details → UPI QR payment → screenshot upload →
Discord approval → email notification → order tracking.

## What's real right now

- Every page and the full click-through flow works.
- The QR code is a real, scannable UPI-format QR — it points at
  `nasooh@fam` with the order amount and ID pre-filled.
- After "I HAVE COMPLETED PAYMENT" + attaching a screenshot, the order
  is posted as a live embed in your Discord channel with **Approve**
  and **Decline** buttons — this is a real, working Discord bot
  integration via Vercel API routes (no separate always-on server
  needed).
- Clicking Approve/Decline in Discord sends a real email from
  `xyzencloud@gmail.com` to the customer.
- Orders on the customer-facing pages (`/dashboard`, `/dashboard/orders`)
  are stored in the browser's local storage — this is a Phase 1
  placeholder and doesn't yet talk to the same store the bot uses.

## ⚠️ Known limitation — read before relying on this

The server-side order store (`lib/server-orders.ts`, used by the bot)
lives in a serverless function's memory. **Vercel does not guarantee
that memory persists between requests** — it often doesn't. This means
an order might "disappear" between the moment it's submitted and the
moment you click Approve, especially if traffic is low. This is fine
for testing today, but **before accepting real customer payments you
must connect a real database** (Supabase is recommended — see below).
Swapping it in only requires editing `lib/server-orders.ts`; nothing
else changes.

## Setting up the Discord bot

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) → your application.
2. **Bot** tab → copy your bot token → this is `DISCORD_BOT_TOKEN`.
3. **General Information** tab → copy "Public Key" → this is `DISCORD_PUBLIC_KEY`.
4. In Discord, enable Developer Mode (User Settings → Advanced), then
   right-click the channel you want orders posted to → Copy Channel ID
   → this is `DISCORD_CHANNEL_ID`.
5. Invite the bot to your server with the `bot` and `applications.commands`
   scopes and `Send Messages` / `Attach Files` permissions.
6. Once deployed to Vercel, go back to your bot's **General Information**
   page and set **Interactions Endpoint URL** to:
   `https://your-domain.vercel.app/api/discord/interactions`
   Discord will send a test ping — it only succeeds once the env vars
   below are set on Vercel and the site is deployed.

## Setting up email

1. Turn on 2-Step Verification on the `xyzencloud@gmail.com` account.
2. Generate an App Password at https://myaccount.google.com/apppasswords
3. Use that (not the real Gmail password) as `GMAIL_PASS`.

## Environment variables

Set these in **Vercel → Project → Settings → Environment Variables**
(see `.env.example` for the full list). Never commit real values to
GitHub.

```
DISCORD_BOT_TOKEN=
DISCORD_PUBLIC_KEY=
DISCORD_CHANNEL_ID=
GMAIL_USER=xyzencloud@gmail.com
GMAIL_PASS=
```

## What's still not built (Phase 2)

- Real database (Supabase) so orders persist reliably and sync between
  the customer dashboard and the bot
- Real authentication/login for customers and admin
- Automatic server provisioning via the Pterodactyl API

## Run it locally

You need [Node.js 20+](https://nodejs.org) installed.

```bash
cd xyzen-cloud
cp .env.example .env.local   # then fill in your real values
npm install
npm run dev
```

Then open http://localhost:3000

Note: Discord interaction verification will reject requests unless
your site is reachable at a public HTTPS URL, so the Approve/Decline
buttons can only be fully tested once deployed to Vercel (or through
a tunnel like `ngrok` for local testing).

## Deploy to Vercel

1. Push this folder to a GitHub repo
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo
3. Add the environment variables listed above
4. Click Deploy
5. Set your Discord bot's Interactions Endpoint URL (see above)

## Project structure

```
app/                       Pages (Next.js App Router)
  api/orders/submit/                   receives order + screenshot, posts to Discord
  api/discord/interactions/            handles Approve/Decline button clicks (the "bot")
  billing/[category]/[plan]/details/   customer form
  billing/[category]/[plan]/payment/   QR payment page
  dashboard/orders/[id]/               order tracking
  admin/orders/                        approve/decline (browser-only preview, temporary)
components/                Reusable UI pieces
lib/plans.ts                Every hosting category & plan (edit prices here)
lib/orders.ts                Browser-side order storage (customer dashboard)
lib/server-orders.ts         Server-side order storage used by the bot — swap for Supabase
lib/discord.ts                Discord embed posting + button verification
lib/email.ts                  Gmail SMTP email sending
```

## Editing prices or adding a plan

Everything lives in `lib/plans.ts`. Find the category, add or edit an
entry in its `plans` array — every page on the site reads from this
one file automatically.

