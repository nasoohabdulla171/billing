import { NextRequest, NextResponse } from "next/server";
import { postOrderEmbed } from "@/lib/discord";
import { saveServerOrder } from "@/lib/server-orders";

// This route accepts multipart/form-data: order fields + a screenshot file.
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();

    const orderId = String(form.get("orderId") || "");
    const categoryName = String(form.get("categoryName") || "");
    const planName = String(form.get("planName") || "");
    const price = Number(form.get("price") || 0);
    const extraOptionLabel = form.get("extraOptionLabel")
      ? String(form.get("extraOptionLabel"))
      : undefined;
    const firstName = String(form.get("firstName") || "");
    const lastName = String(form.get("lastName") || "");
    const username = String(form.get("username") || "");
    const email = String(form.get("email") || "");
    const discordUsername = String(form.get("discordUsername") || "");
    const serverName = String(form.get("serverName") || "");
    const screenshot = form.get("screenshot") as File | null;

    if (!orderId || !email || !screenshot) {
      return NextResponse.json(
        { error: "Missing required fields or screenshot." },
        { status: 400 }
      );
    }

    // Upload the screenshot to Discord by including it directly in the
    // same message as the embed (simplest path — no separate file host
    // needed). We do this with a second request using multipart data.
    const screenshotUrl = await uploadScreenshotAndGetUrl(screenshot, orderId);

    const message = await postOrderEmbed(
      {
        orderId,
        categoryName,
        planName,
        price,
        extraOptionLabel,
        firstName,
        lastName,
        username,
        email,
        discordUsername,
        serverName,
      },
      screenshotUrl
    );

    // Remember which Discord message this order lives in, so we can
    // edit it later when approved/declined.
    saveServerOrder({
      id: orderId,
      categoryName,
      planName,
      price,
      extraOptionLabel,
      firstName,
      lastName,
      username,
      email,
      discordUsername,
      serverName,
      status: "pending",
      discordMessageId: message.id,
      discordChannelId: message.channel_id,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}

/**
 * Uploads the screenshot to Discord's CDN by posting it as a standalone
 * message to the same channel first, then reuses that image URL in the
 * embed. This avoids needing a separate file-hosting service.
 */
async function uploadScreenshotAndGetUrl(file: File, orderId: string): Promise<string> {
  const token = process.env.DISCORD_BOT_TOKEN;
  const channelId = process.env.DISCORD_CHANNEL_ID;
  if (!token || !channelId) throw new Error("Discord bot is not configured.");

  const arrayBuffer = await file.arrayBuffer();
  const blob = new Blob([arrayBuffer], { type: file.type || "image/png" });

  const uploadForm = new FormData();
  uploadForm.append(
    "payload_json",
    JSON.stringify({ content: `Payment screenshot for ${orderId}` })
  );
  uploadForm.append("files[0]", blob, file.name || `${orderId}.png`);

  const res = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
    method: "POST",
    headers: { Authorization: `Bot ${token}` },
    body: uploadForm,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Screenshot upload failed: ${res.status} ${text}`);
  }

  const data = await res.json();
  return data.attachments?.[0]?.url as string;
}
