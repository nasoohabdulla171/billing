import { NextRequest, NextResponse } from "next/server";
import { verifyDiscordRequest, updateOrderEmbed } from "@/lib/discord";
import { getServerOrder, setServerOrderStatus } from "@/lib/server-orders";
import { sendApprovalEmail, sendDeclineEmail } from "@/lib/email";

// Discord interaction type numbers
const PING = 1;
const MESSAGE_COMPONENT = 3;
const MODAL_SUBMIT = 5;

// Discord response type numbers
const PONG = 1;
const CHANNEL_MESSAGE_WITH_SOURCE = 4;
const DEFERRED_UPDATE_MESSAGE = 6;
const MODAL = 9;

export async function POST(req: NextRequest) {
  const signature = req.headers.get("x-signature-ed25519") || "";
  const timestamp = req.headers.get("x-signature-timestamp") || "";
  const rawBody = await req.text();

  const valid = verifyDiscordRequest(rawBody, signature, timestamp);
  if (!valid) {
    return new NextResponse("Invalid request signature", { status: 401 });
  }

  const interaction = JSON.parse(rawBody);

  // Discord's handshake check — must always be answered instantly.
  if (interaction.type === PING) {
    return NextResponse.json({ type: PONG });
  }

  if (interaction.type === MESSAGE_COMPONENT) {
    const customId: string = interaction.data.custom_id;
    const [action, orderId] = customId.split(":");

    if (action === "approve") {
      return handleApprove(orderId);
    }

    if (action === "decline") {
      // Open a modal asking for the decline reason.
      return NextResponse.json({
        type: MODAL,
        data: {
          custom_id: `decline_reason:${orderId}`,
          title: "Decline order",
          components: [
            {
              type: 1,
              components: [
                {
                  type: 4, // text input
                  custom_id: "reason",
                  style: 1,
                  label: "Reason",
                  placeholder: "Payment Not Received, Wrong Amount, Fake Screenshot...",
                  required: true,
                  max_length: 200,
                },
              ],
            },
          ],
        },
      });
    }
  }

  if (interaction.type === MODAL_SUBMIT) {
    const customId: string = interaction.data.custom_id;
    const [action, orderId] = customId.split(":");

    if (action === "decline_reason") {
      const reason: string =
        interaction.data.components[0].components[0].value || "No reason given";
      return handleDecline(orderId, reason);
    }
  }

  return NextResponse.json({ type: DEFERRED_UPDATE_MESSAGE });
}

async function handleApprove(orderId: string) {
  const order = setServerOrderStatus(orderId, "approved");
  if (!order) {
    return NextResponse.json({
      type: CHANNEL_MESSAGE_WITH_SOURCE,
      data: { content: `⚠️ Order ${orderId} not found in this server instance.`, flags: 64 },
    });
  }

  if (order.discordChannelId && order.discordMessageId) {
    await updateOrderEmbed(order.discordChannelId, order.discordMessageId, "approved");
  }

  try {
    await sendApprovalEmail({
      to: order.email,
      firstName: order.firstName,
      username: order.username,
      planName: order.planName,
      serverName: order.serverName,
      orderId: order.id,
    });
  } catch (e) {
    console.error("Approval email failed:", e);
  }

  return NextResponse.json({
    type: CHANNEL_MESSAGE_WITH_SOURCE,
    data: { content: `✅ Order ${orderId} approved. Email sent to ${order.email}.`, flags: 64 },
  });
}

async function handleDecline(orderId: string, reason: string) {
  const order = setServerOrderStatus(orderId, "declined", reason);
  if (!order) {
    return NextResponse.json({
      type: CHANNEL_MESSAGE_WITH_SOURCE,
      data: { content: `⚠️ Order ${orderId} not found in this server instance.`, flags: 64 },
    });
  }

  if (order.discordChannelId && order.discordMessageId) {
    await updateOrderEmbed(order.discordChannelId, order.discordMessageId, "declined", reason);
  }

  try {
    await sendDeclineEmail({
      to: order.email,
      firstName: order.firstName,
      orderId: order.id,
      reason,
    });
  } catch (e) {
    console.error("Decline email failed:", e);
  }

  return NextResponse.json({
    type: CHANNEL_MESSAGE_WITH_SOURCE,
    data: { content: `❌ Order ${orderId} declined (${reason}). Email sent to ${order.email}.`, flags: 64 },
  });
}
