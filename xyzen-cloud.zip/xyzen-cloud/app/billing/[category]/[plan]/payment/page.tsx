import Link from "next/link";
import { notFound } from "next/navigation";
import { getCategory, getPlan } from "@/lib/plans";
import StepBar from "@/components/StepBar";
import OrderLoader from "@/components/OrderLoader";

export default function PaymentPage({
  params,
  searchParams,
}: {
  params: { category: string; plan: string };
  searchParams: { order?: string };
}) {
  const category = getCategory(params.category);
  const plan = getPlan(params.category, params.plan);
  if (!category || !plan || !searchParams.order) notFound();

  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <StepBar current={5} />

      <div className="mb-2">
        <Link href={`/billing/${category.id}/${plan.id}/details`} className="font-mono text-xs text-white/40 hover:text-white">
          ← Back
        </Link>
      </div>
      <h1 className="mt-2 font-display text-3xl font-semibold text-white sm:text-4xl">
        Complete your payment
      </h1>
      <p className="mt-2 text-white/60">Scan the code below or use the UPI ID directly.</p>

      <div className="mt-10">
        <OrderLoader orderId={searchParams.order} />
      </div>
    </section>
  );
}
