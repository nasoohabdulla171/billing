import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { CATEGORIES, getCategory, getPlan } from "@/lib/plans";
import StepBar from "@/components/StepBar";
import ExtraOptionPicker from "@/components/ExtraOptionPicker";

export function generateStaticParams() {
  return CATEGORIES.flatMap((c) => c.plans.map((p) => ({ category: c.id, plan: p.id })));
}

export default function PlanOptionsPage({
  params,
}: {
  params: { category: string; plan: string };
}) {
  const category = getCategory(params.category);
  const plan = getPlan(params.category, params.plan);
  if (!category || !plan) notFound();

  // Categories with no extra option skip straight to the details form.
  if (!category.extraOption) {
    redirect(`/billing/${category.id}/${plan.id}/details`);
  }

  return (
    <section className="mx-auto max-w-3xl px-5 py-16">
      <StepBar current={3} />

      <div className="mb-2">
        <Link href={`/billing/${category.id}`} className="font-mono text-xs text-white/40 hover:text-white">
          ← Back to plans
        </Link>
      </div>
      <h1 className="mt-2 font-display text-3xl font-semibold text-white sm:text-4xl">
        {category.extraOption.label}
      </h1>
      <p className="mt-2 text-white/60">
        {plan.name} · {category.name} — one more thing before we set this up.
      </p>

      <div className="mt-10">
        <ExtraOptionPicker option={category.extraOption} categoryId={category.id} planId={plan.id} />
      </div>
    </section>
  );
}
