import Link from "next/link";
import { notFound } from "next/navigation";
import { getCategory, getPlan } from "@/lib/plans";
import StepBar from "@/components/StepBar";
import DetailsForm from "@/components/DetailsForm";
import OrderSummary from "@/components/OrderSummary";

const OPTION_LABELS: Record<string, string> = {
  python: "Python", nodejs: "Node.js", samp: "SA-MP", omp: "Open Multiplayer (OMP)",
};

export default function DetailsPage({
  params,
  searchParams,
}: {
  params: { category: string; plan: string };
  searchParams: { opt?: string };
}) {
  const category = getCategory(params.category);
  const plan = getPlan(params.category, params.plan);
  if (!category || !plan) notFound();

  const extraOptionLabel = searchParams.opt ? OPTION_LABELS[searchParams.opt] : undefined;

  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <StepBar current={4} />

      <div className="mb-2">
        <Link href={`/billing/${category.id}/${plan.id}`} className="font-mono text-xs text-white/40 hover:text-white">
          ← Back
        </Link>
      </div>
      <h1 className="mt-2 font-display text-3xl font-semibold text-white sm:text-4xl">
        Your details
      </h1>
      <p className="mt-2 text-white/60">Tell us where to set up your server.</p>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_340px]">
        <DetailsForm category={category} plan={plan} extraOptionLabel={extraOptionLabel} />
        <div className="lg:sticky lg:top-24 lg:self-start">
          <OrderSummary category={category} plan={plan} extraOptionLabel={extraOptionLabel} />
        </div>
      </div>
    </section>
  );
}
