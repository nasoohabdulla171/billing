import Link from "next/link";
import { notFound } from "next/navigation";
import { Check, Cpu, Database, HardDrive, Users } from "lucide-react";
import { CATEGORIES, getCategory } from "@/lib/plans";
import StepBar from "@/components/StepBar";

export function generateStaticParams() {
  return CATEGORIES.map((c) => ({ category: c.id }));
}

export default function CategoryPlansPage({ params }: { params: { category: string } }) {
  const category = getCategory(params.category);
  if (!category) notFound();

  return (
    <section className="mx-auto max-w-7xl px-5 py-16">
      <StepBar current={2} />

      <div className="mb-2">
        <Link href="/billing" className="font-mono text-xs text-white/40 hover:text-white">
          ← All categories
        </Link>
      </div>
      <h1 className="mt-2 font-display text-3xl font-semibold text-white sm:text-4xl">
        {category.name}
      </h1>
      <p className="mt-2 text-white/60">{category.tagline}</p>

      <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {category.plans.map((plan) => (
          <Link
            key={plan.id}
            href={`/billing/${category.id}/${plan.id}`}
            className={
              "group relative flex flex-col rounded-xl border p-6 transition focus-ring " +
              (plan.highlight
                ? "border-signal/60 bg-panel-2 shadow-[0_0_40px_-12px_rgba(124,92,255,0.5)]"
                : "border-line bg-panel hover:border-signal/40 hover:bg-panel-2")
            }
          >
            {plan.highlight && (
              <span className="absolute -top-3 left-6 rounded-full bg-signal px-2.5 py-0.5 font-mono text-[10px] font-medium text-white">
                MOST POPULAR
              </span>
            )}
            <h3 className="font-display text-lg font-semibold text-white">{plan.name}</h3>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="font-display text-3xl font-semibold text-white">₹{plan.price}</span>
              <span className="font-mono text-xs text-white/40">/mo</span>
            </div>

            <div className="mt-5 space-y-2 border-t border-line pt-5">
              {plan.specs.map((s) => (
                <div key={s.label} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-white/50">
                    <SpecIcon label={s.label} /> {s.label}
                  </span>
                  <span className="font-mono text-white/80">{s.value}</span>
                </div>
              ))}
            </div>

            <div className="mt-auto pt-6">
              <span className="flex w-full items-center justify-center gap-2 rounded-lg bg-white/5 py-2.5 text-sm font-medium text-white transition group-hover:bg-signal">
                <Check size={15} /> Select {plan.name}
              </span>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-14 rounded-xl border border-line bg-panel/60 p-6">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">Every plan includes</p>
        <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2 sm:grid-cols-3">
          {category.includes.map((inc) => (
            <div key={inc} className="flex items-center gap-2 text-sm text-white/60">
              <Check size={13} className="shrink-0 text-mint" /> {inc}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SpecIcon({ label }: { label: string }) {
  const l = label.toLowerCase();
  if (l.includes("ram")) return <Cpu size={13} />;
  if (l.includes("storage") || l.includes("ssd")) return <HardDrive size={13} />;
  if (l.includes("player") || l.includes("slot")) return <Users size={13} />;
  if (l.includes("database")) return <Database size={13} />;
  return <Cpu size={13} />;
}
