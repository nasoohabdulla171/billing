import Link from "next/link";
import { ArrowRight, Server } from "lucide-react";
import { CATEGORIES } from "@/lib/plans";

export default function BillingPage() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-16">
      <div className="mb-10">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">Step 1 of 5</p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-white sm:text-4xl">
          Choose a hosting category
        </h1>
        <p className="mt-2 max-w-lg text-white/60">
          Every category runs on DDoS-protected India nodes with instant setup.
          Pick one to see plans.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CATEGORIES.map((cat) => (
          <Link
            key={cat.id}
            href={`/billing/${cat.id}`}
            className="group relative overflow-hidden rounded-xl border border-line bg-panel p-6 transition hover:border-signal/50 hover:bg-panel-2 focus-ring"
          >
            <div className="flex items-start justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-signal/10 text-signal">
                <Server size={18} />
              </div>
              <span className="flex items-center gap-1.5 font-mono text-[10px] text-mint">
                <span className="h-1.5 w-1.5 rounded-full bg-mint" /> available
              </span>
            </div>
            <h3 className="mt-5 font-display text-lg font-semibold text-white">{cat.name}</h3>
            <p className="mt-1.5 text-sm text-white/50">{cat.tagline}</p>
            <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
              <span className="font-mono text-xs text-white/40">
                {cat.plans.length} plans · from ₹{Math.min(...cat.plans.map((p) => p.price))}/mo
              </span>
              <ArrowRight size={15} className="text-white/30 transition group-hover:translate-x-0.5 group-hover:text-signal" />
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
