import Link from "next/link";
import { ArrowRight, ShieldCheck, Zap, Server, MessageCircle } from "lucide-react";
import ConsoleReadout from "@/components/ConsoleReadout";
import { CATEGORIES } from "@/lib/plans";

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-line/60 bg-grid-fade">
        <div className="pointer-events-none absolute -top-24 left-1/2 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-signal/10 blur-3xl" />
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 md:grid-cols-2 md:items-center md:py-28">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-panel/60 px-3 py-1 font-mono text-[11px] text-white/60">
              <span className="h-1.5 w-1.5 animate-pulseGlow rounded-full bg-mint" />
              India node · stock available
            </div>
            <h1 className="font-display text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl">
              Servers that boot before
              <br />
              you finish your coffee.
            </h1>
            <p className="mt-5 max-w-md text-white/60">
              Minecraft, FiveM, SA-MP and Discord bot hosting on AMD EPYC and
              Intel Xeon hardware. DDoS-shielded, instantly deployed, priced
              for server owners — not enterprises.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/billing"
                className="group inline-flex items-center gap-2 rounded-lg bg-signal px-5 py-3 text-sm font-semibold text-white shadow-[0_0_25px_-5px_rgba(124,92,255,0.8)] transition hover:bg-signal/90 focus-ring"
              >
                Get Started
                <ArrowRight size={16} className="transition group-hover:translate-x-0.5" />
              </Link>
              <Link
                href="/billing"
                className="rounded-lg border border-line px-5 py-3 text-sm font-medium text-white/80 transition hover:border-signal/60 hover:text-white focus-ring"
              >
                View Plans
              </Link>
              <a
                href="https://discord.gg/NpgkzC97zV"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-medium text-white/60 transition hover:text-white focus-ring"
              >
                <MessageCircle size={16} /> Discord Support
              </a>
            </div>
          </div>

          <div className="flex justify-center md:justify-end">
            <div className="animate-drift">
              <ConsoleReadout />
            </div>
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section className="border-b border-line/60 bg-panel/40">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-5 py-8 sm:grid-cols-3">
          <Feature icon={<Zap size={18} />} title="Instant provisioning" desc="Panel access the moment your order is approved." />
          <Feature icon={<ShieldCheck size={18} />} title="DDoS shielded" desc="Enterprise-grade protection on every node, every plan." />
          <Feature icon={<Server size={18} />} title="EPYC & Xeon hardware" desc="Real dedicated cores — not oversold shared boxes." />
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-signal">Hosting catalog</p>
            <h2 className="mt-2 font-display text-2xl font-semibold text-white sm:text-3xl">
              Pick what you're building
            </h2>
          </div>
          <Link href="/billing" className="hidden font-mono text-xs text-white/50 hover:text-white sm:block">
            View all →
          </Link>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              href={`/billing/${cat.id}`}
              className="group relative overflow-hidden rounded-xl border border-line bg-panel p-5 transition hover:border-signal/50 hover:bg-panel-2 focus-ring"
            >
              <div className="flex items-start justify-between">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-signal/10 text-signal">
                  <Server size={16} />
                </div>
                <span className="flex items-center gap-1.5 font-mono text-[10px] text-mint">
                  <span className="h-1.5 w-1.5 rounded-full bg-mint" /> available
                </span>
              </div>
              <h3 className="mt-4 font-display text-base font-semibold text-white">{cat.name}</h3>
              <p className="mt-1 text-xs text-white/50">{cat.tagline}</p>
              <div className="mt-4 flex items-center justify-between border-t border-line pt-3">
                <span className="font-mono text-xs text-white/40">
                  from ₹{Math.min(...cat.plans.map((p) => p.price))}/mo
                </span>
                <ArrowRight size={14} className="text-white/30 transition group-hover:translate-x-0.5 group-hover:text-signal" />
              </div>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-signal/10 text-signal">
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-white">{title}</p>
        <p className="text-xs text-white/50">{desc}</p>
      </div>
    </div>
  );
}
