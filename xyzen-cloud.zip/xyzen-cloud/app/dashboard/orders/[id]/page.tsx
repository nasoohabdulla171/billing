import OrderDetailClient from "@/components/OrderDetailClient";

export default function OrderPage({ params }: { params: { id: string } }) {
  return <OrderDetailClient orderId={params.id} />;
}
