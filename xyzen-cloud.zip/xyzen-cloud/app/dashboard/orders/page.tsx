import OrdersListClient from "@/components/OrdersListClient";

export default function OrdersPage() {
  return <OrdersListClient />;
}
