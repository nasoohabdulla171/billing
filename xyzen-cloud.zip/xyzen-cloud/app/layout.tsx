import type { Metadata } from "next";
import "./globals.css";
import FloatingSupport from "@/components/FloatingSupport";
import SiteHeader from "@/components/SiteHeader";

export const metadata: Metadata = {
  title: "XYZEN CLOUD — Premium Game & Bot Hosting",
  description:
    "Minecraft, FiveM, SA-MP and Discord bot hosting on AMD EPYC and Intel Xeon nodes. Instant setup, DDoS protection, India-based low-latency servers.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-noise min-h-screen antialiased">
        <SiteHeader />
        <main>{children}</main>
        <FloatingSupport />
      </body>
    </html>
  );
}
