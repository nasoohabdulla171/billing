// ─────────────────────────────────────────────────────────────
// Order storage.
// PHASE 1: saved in the browser (localStorage) so the full flow
//          works end-to-end without a backend.
// PHASE 2: replace the body of each function below with a call
//          to Supabase. Nothing in the pages needs to change —
//          they only import { createOrder, getOrder, ... } from
//          here.
// ─────────────────────────────────────────────────────────────

export type OrderStatus = "pending" | "approved" | "declined";

export type Order = {
  id: string;
  createdAt: string;
  status: OrderStatus;
  declineReason?: string;

  categoryId: string;
  categoryName: string;
  planId: string;
  planName: string;
  price: number;
  extraOptionLabel?: string;

  firstName: string;
  lastName: string;
  username: string;
  email: string;
  phone?: string;
  discordUsername: string;
  country: string;
  state: string;
  city: string;
  serverName: string;
  os?: string;
  notes?: string;
};

const KEY = "xyzen_orders";

function readAll(): Order[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Order[]) : [];
  } catch {
    return [];
  }
}

function writeAll(orders: Order[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(orders));
}

export function createOrder(data: Omit<Order, "id" | "createdAt" | "status">): Order {
  const order: Order = {
    ...data,
    id: "XYZ-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
    createdAt: new Date().toISOString(),
    status: "pending",
  };
  const all = readAll();
  all.unshift(order);
  writeAll(all);
  return order;
}

export function getOrder(id: string): Order | undefined {
  return readAll().find((o) => o.id === id);
}

export function getAllOrders(): Order[] {
  return readAll();
}

export function updateOrderStatus(id: string, status: OrderStatus, declineReason?: string) {
  const all = readAll();
  const idx = all.findIndex((o) => o.id === id);
  if (idx === -1) return;
  all[idx].status = status;
  if (declineReason) all[idx].declineReason = declineReason;
  writeAll(all);
}
