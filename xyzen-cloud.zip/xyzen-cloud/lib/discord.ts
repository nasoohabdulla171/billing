// ─────────────────────────────────────────────────────────────
// Discord integration.
// Env vars required (set these in Vercel → Settings → Environment
// Variables, never in code):
//   DISCORD_BOT_TOKEN      the bot token from the Developer Portal
//   DISCORD_CHANNEL_ID     the channel new orders get posted to
//   DISCORD_PUBLIC_KEY     "Public Key" from the same bot's page
//                          (used to verify button clicks are real)
// ─────────────────────────────────────────────────────────────

import nacl from "tweetnacl";

const DISCORD_API = "https://discord.com/api/v10";

export type OrderEmbedData = {
  orderId: string;
  categoryName: string;
  planName: string;
  price: number;
  extraOptionLabel?: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  discordUsername: string;
  serverName: string;
};

/**
 * Posts the "NEW ORDER" embed with Approve / Decline buttons to the
 * configured channel. If a screenshot URL is provided, it's attached
 * as the embed image.
 */
export async function postOrderEmbed(order: OrderEmbedData, screenshotUrl?: string) {
  const token = process.env.DISCORD_BOT_TOKEN;
  const channelId = process.env.DISCORD_CHANNEL_ID;
  if (!token || !channelId) {
    throw new Error("Discord bot is not configured (missing env vars).");
  }

  const embed = {
    title: "🟣 XYZEN CLOUD — New Order",
    color: 0x7c5cff,
    fields: [
      { name: "Order ID", value: order.orderId, inline: true },
      { name: "Amount", value: `₹${order.price}`, inline: true },
      { name: "Category", value: order.categoryName, inline: true },
      { name: "Plan", value: order.planName, inline: true },
      ...(order.extraOptionLabel
        ? [{ name: "Option", value: order.extraOptionLabel, inline: true }]
        : []),
      { name: "Customer", value: `${order.firstName} ${order.lastName}`, inline: true },
      { name: "Username", value: order.username, inline: true },
      { name: "Email", value: order.email, inline: true },
      { name: "Discord", value: order.discordUsername, inline: true },
      { name: "Server Name", value: order.serverName, inline: true },
    ],
    image: screenshotUrl ? { url: screenshotUrl } : undefined,
    footer: { text: "Payment screenshot attached above" },
    timestamp: new Date().toISOString(),
  };

  const components = [
    {
      type: 1, // action row
      components: [
        {
          type: 2, // button
          style: 3, // green
          label: "Approve",
          custom_id: `approve:${order.orderId}`,
        },
        {
          type: 2,
          style: 4, // red
          label: "Decline",
          custom_id: `decline:${order.orderId}`,
        },
      ],
    },
  ];

  const res = await fetch(`${DISCORD_API}/channels/${channelId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ embeds: [embed], components }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Discord post failed: ${res.status} ${text}`);
  }

  return res.json();
}

/** Edits the original order embed after it's been approved/declined. */
export async function updateOrderEmbed(
  channelId: string,
  messageId: string,
  status: "approved" | "declined",
  reason?: string
) {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error("Missing DISCORD_BOT_TOKEN");

  const statusLine =
    status === "approved"
      ? "✅ **APPROVED**"
      : `❌ **DECLINED**${reason ? ` — ${reason}` : ""}`;

  await fetch(`${DISCORD_API}/channels/${channelId}/messages/${messageId}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      content: statusLine,
      components: [], // remove the buttons once actioned
    }),
  });
}

/**
 * Verifies that an incoming interaction request really came from
 * Discord (not a forged request). Required by Discord for all
 * HTTP-based interaction endpoints.
 */
export function verifyDiscordRequest(
  body: string,
  signature: string,
  timestamp: string
): boolean {
  const publicKey = process.env.DISCORD_PUBLIC_KEY;
  if (!publicKey) return false;

  try {
    return nacl.sign.detached.verify(
      Buffer.from(timestamp + body),
      Buffer.from(signature, "hex"),
      Buffer.from(publicKey, "hex")
    );
  } catch {
    return false;
  }
}
