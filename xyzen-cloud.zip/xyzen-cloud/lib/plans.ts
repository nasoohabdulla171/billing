// ─────────────────────────────────────────────────────────────
// XYZEN CLOUD — plan catalog
// This file is the single source of truth for every category and
// plan shown on the site. To change a price or add a plan, edit
// only this file — every page reads from here.
// ─────────────────────────────────────────────────────────────

export type Spec = { label: string; value: string };

export type Plan = {
  id: string;
  name: string;
  price: number; // in INR, per month
  specs: Spec[];
  highlight?: boolean; // marks a "most popular" plan
};

export type ExtraOptionGroup = {
  label: string; // e.g. "Hosting Language"
  choices: { id: string; label: string }[];
};

export type Category = {
  id: string;
  name: string;
  tagline: string;
  cpuLabel: string; // e.g. "AMD EPYC™ Nodes"
  node: string;
  storageUnit: string; // "NVMe SSD" vs "SSD"
  plans: Plan[];
  includes: string[];
  extraOption?: ExtraOptionGroup;
};

export const CATEGORIES: Category[] = [
  {
    id: "minecraft-premium",
    name: "Minecraft Premium",
    tagline: "AMD EPYC™ Nodes · Zero-lag world hosting",
    cpuLabel: "AMD EPYC™ Premium CPU",
    node: "India",
    storageUnit: "NVMe SSD",
    plans: [
      { id: "starter", name: "Starter", price: 99, specs: [
        { label: "RAM", value: "1 GB" }, { label: "CPU", value: "100%" },
        { label: "Storage", value: "10 GB NVMe" }, { label: "Players", value: "5–15" },
        { label: "Database", value: "1" }, { label: "Backups", value: "1" }, { label: "Allocations", value: "1" },
      ]},
      { id: "basic", name: "Basic", price: 199, specs: [
        { label: "RAM", value: "2 GB" }, { label: "CPU", value: "150%" },
        { label: "Storage", value: "20 GB NVMe" }, { label: "Players", value: "10–30" },
        { label: "Database", value: "1" }, { label: "Backups", value: "2" }, { label: "Allocations", value: "2" },
      ]},
      { id: "pro", name: "Pro", price: 349, specs: [
        { label: "RAM", value: "4 GB" }, { label: "CPU", value: "200%" },
        { label: "Storage", value: "40 GB NVMe" }, { label: "Players", value: "25–60" },
        { label: "Database", value: "2" }, { label: "Backups", value: "3" }, { label: "Allocations", value: "3" },
      ], highlight: true },
      { id: "premium", name: "Premium", price: 599, specs: [
        { label: "RAM", value: "8 GB" }, { label: "CPU", value: "300%" },
        { label: "Storage", value: "80 GB NVMe" }, { label: "Players", value: "50–120" },
        { label: "Database", value: "4" }, { label: "Backups", value: "5" }, { label: "Allocations", value: "6" },
      ]},
      { id: "extreme", name: "Extreme", price: 799, specs: [
        { label: "RAM", value: "16 GB" }, { label: "CPU", value: "500%" },
        { label: "Storage", value: "160 GB NVMe" }, { label: "Players", value: "100–250" },
        { label: "Database", value: "4" }, { label: "Backups", value: "6" }, { label: "Allocations", value: "6" },
      ]},
      { id: "ultimate", name: "Ultimate", price: 1399, specs: [
        { label: "RAM", value: "32 GB" }, { label: "CPU", value: "800%" },
        { label: "Storage", value: "320 GB NVMe" }, { label: "Players", value: "250–500+" },
        { label: "Database", value: "Unlimited" }, { label: "Backups", value: "Unlimited" }, { label: "Allocations", value: "Unlimited" },
      ]},
    ],
    includes: [
      "AMD EPYC Premium CPU", "Advanced DDoS Protection", "Instant Setup",
      "High-Speed NVMe SSD Storage", "Full Pterodactyl Panel Access", "SFTP File Access",
      "One-Click Reinstall", "Unlimited Bandwidth", "India Location Node",
      "99.9% Uptime Guarantee", "Premium Support",
    ],
  },
  {
    id: "minecraft-budget",
    name: "Minecraft Budget",
    tagline: "Intel Xeon Budget Nodes · Same features, lower cost",
    cpuLabel: "Intel Xeon Budget CPU",
    node: "India",
    storageUnit: "SSD",
    plans: [
      { id: "starter", name: "Starter", price: 49, specs: [
        { label: "RAM", value: "1 GB" }, { label: "CPU", value: "100%" },
        { label: "Storage", value: "10 GB SSD" }, { label: "Players", value: "5–15" },
        { label: "Database", value: "1" }, { label: "Backups", value: "1" }, { label: "Allocations", value: "1" },
      ]},
      { id: "basic", name: "Basic", price: 109, specs: [
        { label: "RAM", value: "2 GB" }, { label: "CPU", value: "150%" },
        { label: "Storage", value: "20 GB SSD" }, { label: "Players", value: "10–30" },
        { label: "Database", value: "1" }, { label: "Backups", value: "2" }, { label: "Allocations", value: "2" },
      ]},
      { id: "pro", name: "Pro", price: 199, specs: [
        { label: "RAM", value: "4 GB" }, { label: "CPU", value: "200%" },
        { label: "Storage", value: "40 GB SSD" }, { label: "Players", value: "25–60" },
        { label: "Database", value: "2" }, { label: "Backups", value: "3" }, { label: "Allocations", value: "3" },
      ], highlight: true },
      { id: "premium", name: "Premium", price: 279, specs: [
        { label: "RAM", value: "8 GB" }, { label: "CPU", value: "300%" },
        { label: "Storage", value: "80 GB SSD" }, { label: "Players", value: "50–120" },
        { label: "Database", value: "4" }, { label: "Backups", value: "5" }, { label: "Allocations", value: "6" },
      ]},
      { id: "extreme", name: "Extreme", price: 409, specs: [
        { label: "RAM", value: "16 GB" }, { label: "CPU", value: "500%" },
        { label: "Storage", value: "160 GB SSD" }, { label: "Players", value: "100–250" },
        { label: "Database", value: "4" }, { label: "Backups", value: "6" }, { label: "Allocations", value: "6" },
      ]},
      { id: "ultimate", name: "Ultimate", price: 699, specs: [
        { label: "RAM", value: "32 GB" }, { label: "CPU", value: "800%" },
        { label: "Storage", value: "320 GB SSD" }, { label: "Players", value: "250–500+" },
        { label: "Database", value: "Unlimited" }, { label: "Backups", value: "Unlimited" }, { label: "Allocations", value: "Unlimited" },
      ]},
    ],
    includes: [
      "Intel Xeon Budget CPU", "Advanced DDoS Protection", "Instant Setup",
      "High-Speed NVMe SSD Storage", "Full Pterodactyl Panel Access", "SFTP File Access",
      "One-Click Reinstall", "Unlimited Bandwidth", "India Location Node",
      "99.9% Uptime Guarantee", "Premium Support",
    ],
  },
  {
    id: "bot-hosting",
    name: "Discord Bot Hosting",
    tagline: "AMD EPYC / Intel Xeon · Python · Node.js · Java",
    cpuLabel: "AMD EPYC / Intel Xeon",
    node: "India",
    storageUnit: "SSD",
    plans: [
      { id: "plan1", name: "Bot Plan 1", price: 39, specs: [
        { label: "CPU", value: "25%" }, { label: "RAM", value: "512 MB" }, { label: "SSD", value: "5 GB" },
      ]},
      { id: "plan2", name: "Bot Plan 2", price: 59, specs: [
        { label: "CPU", value: "50%" }, { label: "RAM", value: "1 GB" }, { label: "SSD", value: "10 GB" },
      ]},
      { id: "plan3", name: "Bot Plan 3", price: 99, specs: [
        { label: "CPU", value: "75%" }, { label: "RAM", value: "2 GB" }, { label: "SSD", value: "15 GB" },
      ], highlight: true },
      { id: "plan4", name: "Bot Plan 4", price: 149, specs: [
        { label: "CPU", value: "100%" }, { label: "RAM", value: "4 GB" }, { label: "SSD", value: "25 GB" },
      ]},
      { id: "plan5", name: "Bot Plan 5", price: 249, specs: [
        { label: "CPU", value: "150%" }, { label: "RAM", value: "8 GB" }, { label: "SSD", value: "50 GB" },
      ]},
      { id: "plan6", name: "Bot Plan 6", price: 449, specs: [
        { label: "CPU", value: "250%" }, { label: "RAM", value: "16 GB" }, { label: "SSD", value: "100 GB" },
      ]},
    ],
    includes: [
      "Advanced DDoS Protection", "Instant Setup", "Full Pterodactyl Panel Access",
      "Free MySQL Database", "Daily Automatic Backups", "Unlimited Reinstalls",
      "GitHub Repository Support", "Unlimited Bandwidth", "99.9% Uptime Guarantee",
      "Low Latency (30–50ms)", "24/7 Premium Support",
    ],
    extraOption: {
      label: "Hosting Language",
      choices: [
        { id: "python", label: "Python" },
        { id: "nodejs", label: "Node.js" },
      ],
    },
  },
  {
    id: "samp-hosting",
    name: "SA-MP Hosting",
    tagline: "AMD EPYC / Intel Xeon Nodes · Roleplay-ready",
    cpuLabel: "AMD EPYC / Intel Xeon",
    node: "India",
    storageUnit: "SSD",
    plans: [
      { id: "beginner", name: "Beginner", price: 49, specs: [
        { label: "RAM", value: "512 MB" }, { label: "CPU", value: "50%" }, { label: "Storage", value: "5 GB SSD" }, { label: "Players", value: "5–20" },
      ]},
      { id: "rookie", name: "Rookie", price: 79, specs: [
        { label: "RAM", value: "1 GB" }, { label: "CPU", value: "100%" }, { label: "Storage", value: "5 GB SSD" }, { label: "Players", value: "20–40" },
      ]},
      { id: "street", name: "Street", price: 139, specs: [
        { label: "RAM", value: "2 GB" }, { label: "CPU", value: "150%" }, { label: "Storage", value: "10 GB SSD" }, { label: "Players", value: "40–80" },
      ]},
      { id: "gangster", name: "Gangster", price: 179, specs: [
        { label: "RAM", value: "4 GB" }, { label: "CPU", value: "200%" }, { label: "Storage", value: "20 GB SSD" }, { label: "Players", value: "80–150" },
      ], highlight: true },
      { id: "mafia", name: "Mafia", price: 279, specs: [
        { label: "RAM", value: "8 GB" }, { label: "CPU", value: "300%" }, { label: "Storage", value: "40 GB SSD" }, { label: "Players", value: "150–300" },
      ]},
      { id: "godfather", name: "Godfather", price: 429, specs: [
        { label: "RAM", value: "16 GB" }, { label: "CPU", value: "500%" }, { label: "Storage", value: "80 GB SSD" }, { label: "Players", value: "300–500" },
      ]},
      { id: "legend", name: "Legend", price: 729, specs: [
        { label: "RAM", value: "32 GB" }, { label: "CPU", value: "800%" }, { label: "Storage", value: "160 GB SSD" }, { label: "Players", value: "500–1000" },
      ]},
    ],
    includes: [
      "AMD EPYC / Intel Xeon CPU", "Advanced DDoS Protection", "30–50ms Low Ping",
      "Instant Setup", "Daily Backups", "Free Database", "Free Backup Restore", "Fast Support",
    ],
    extraOption: {
      label: "Server Type",
      choices: [
        { id: "samp", label: "SA-MP" },
        { id: "omp", label: "Open Multiplayer (OMP)" },
      ],
    },
  },
  {
    id: "web-hosting",
    name: "Web Hosting",
    tagline: "AMD EPYC Premium · LiteSpeed powered",
    cpuLabel: "AMD EPYC Premium",
    node: "India",
    storageUnit: "SSD",
    plans: [
      { id: "starter", name: "Starter", price: 49, specs: [
        { label: "RAM", value: "1 GB" }, { label: "CPU", value: "100%" }, { label: "Storage", value: "5 GB" }, { label: "Bandwidth", value: "Unlimited" },
      ]},
      { id: "basic", name: "Basic", price: 99, specs: [
        { label: "RAM", value: "2 GB" }, { label: "CPU", value: "150%" }, { label: "Storage", value: "15 GB" }, { label: "Bandwidth", value: "Unlimited" },
      ]},
      { id: "pro", name: "Pro", price: 199, specs: [
        { label: "RAM", value: "4 GB" }, { label: "CPU", value: "200%" }, { label: "Storage", value: "30 GB" }, { label: "Websites", value: "20" }, { label: "Bandwidth", value: "Unlimited" },
      ], highlight: true },
      { id: "business", name: "Business", price: 399, specs: [
        { label: "RAM", value: "8 GB" }, { label: "CPU", value: "300%" }, { label: "Storage", value: "60 GB" }, { label: "Bandwidth", value: "Unlimited" },
      ]},
    ],
    includes: [
      "LiteSpeed Web Server", "High-Performance SSD Storage", "Unlimited Bandwidth",
      "File Manager & FTP Access", "MySQL Databases", "Advanced DDoS Protection",
      "99.9% Uptime Guarantee", "Softaculous 1-Click Installer", "Daily Backups (Business Plans)",
      "Premium Technical Support",
    ],
  },
  {
    id: "fivem-hosting",
    name: "FiveM Hosting",
    tagline: "AMD EPYC Premium · FXServer Ready",
    cpuLabel: "AMD EPYC Premium",
    node: "India",
    storageUnit: "NVMe SSD",
    plans: [
      { id: "starter", name: "Starter", price: 199, specs: [
        { label: "RAM", value: "2 GB" }, { label: "CPU", value: "150%" }, { label: "Storage", value: "20 GB NVMe" },
        { label: "Slots", value: "16–32" }, { label: "Database", value: "2" }, { label: "Backups", value: "2" }, { label: "Allocations", value: "2" },
      ]},
      { id: "basic", name: "Basic", price: 399, specs: [
        { label: "RAM", value: "4 GB" }, { label: "CPU", value: "200%" }, { label: "Storage", value: "40 GB NVMe" },
        { label: "Slots", value: "32–64" }, { label: "Database", value: "3" }, { label: "Backups", value: "5" }, { label: "Allocations", value: "5" },
      ]},
      { id: "pro", name: "Pro", price: 699, specs: [
        { label: "RAM", value: "8 GB" }, { label: "CPU", value: "300%" }, { label: "Storage", value: "80 GB NVMe" },
        { label: "Slots", value: "64–128" }, { label: "Database", value: "5" }, { label: "Backups", value: "8" }, { label: "Allocations", value: "8" },
      ], highlight: true },
      { id: "premium", name: "Premium", price: 1199, specs: [
        { label: "RAM", value: "12 GB" }, { label: "CPU", value: "400%" }, { label: "Storage", value: "120 GB NVMe" },
        { label: "Slots", value: "128–256" }, { label: "Database", value: "8" }, { label: "Backups", value: "10" }, { label: "Allocations", value: "10" },
      ]},
      { id: "extreme", name: "Extreme", price: 1999, specs: [
        { label: "RAM", value: "16 GB" }, { label: "CPU", value: "500%" }, { label: "Storage", value: "160 GB NVMe" },
        { label: "Slots", value: "256–512" }, { label: "Database", value: "10" }, { label: "Backups", value: "15" }, { label: "Allocations", value: "15" },
      ]},
      { id: "ultimate", name: "Ultimate", price: 3499, specs: [
        { label: "RAM", value: "32 GB" }, { label: "CPU", value: "800%" }, { label: "Storage", value: "320 GB NVMe" },
        { label: "Slots", value: "512+" }, { label: "Database", value: "Unlimited" }, { label: "Backups", value: "Unlimited" }, { label: "Allocations", value: "Unlimited" },
      ]},
    ],
    includes: [
      "AMD EPYC Premium Processors", "Optimized for FiveM Roleplay Servers", "Enterprise DDoS Protection",
      "Instant Server Deployment", "Ultra-Fast NVMe SSD Storage", "Full Pterodactyl Panel Access",
      "SFTP File Access", "One-Click Reinstall", "Unlimited Bandwidth", "Low-Latency Network",
      "99.9% Uptime Guarantee", "FXServer Ready", "Full Console Access", "Automatic Backups",
      "Premium Technical Support",
    ],
  },
  {
    id: "amd-epyc-vps",
    name: "AMD EPYC VPS",
    tagline: "Premium KVM VPS · EPYC 7F72 / 7K62",
    cpuLabel: "AMD EPYC Premium",
    node: "India",
    storageUnit: "NVMe SSD",
    plans: [
      { id: "xs", name: "XS", price: 429, specs: [{ label: "CPU", value: "2 vCores" }, { label: "RAM", value: "6 GB DDR4 ECC" }, { label: "Storage", value: "50 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "s", name: "S", price: 659, specs: [{ label: "CPU", value: "2 vCores" }, { label: "RAM", value: "8 GB DDR4 ECC" }, { label: "Storage", value: "80 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "m", name: "M", price: 1099, specs: [{ label: "CPU", value: "4 vCores" }, { label: "RAM", value: "12 GB DDR4 ECC" }, { label: "Storage", value: "100 GB NVMe" }, { label: "Port", value: "1 Gbps" }], highlight: true },
      { id: "l", name: "L", price: 1299, specs: [{ label: "CPU", value: "6 vCores" }, { label: "RAM", value: "16 GB DDR4 ECC" }, { label: "Storage", value: "150 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "xl", name: "XL", price: 1699, specs: [{ label: "CPU", value: "6 vCores" }, { label: "RAM", value: "24 GB DDR4 ECC" }, { label: "Storage", value: "200 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "xxl", name: "XXL", price: 2099, specs: [{ label: "CPU", value: "8 vCores" }, { label: "RAM", value: "32 GB DDR4 ECC" }, { label: "Storage", value: "300 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "2xl", name: "2XL", price: 2599, specs: [{ label: "CPU", value: "10 vCores" }, { label: "RAM", value: "48 GB DDR4 ECC" }, { label: "Storage", value: "350 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "3xl", name: "3XL", price: 3599, specs: [{ label: "CPU", value: "12 vCores" }, { label: "RAM", value: "64 GB DDR4 ECC" }, { label: "Storage", value: "400 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
    ],
    includes: [
      "AMD EPYC Enterprise CPU", "KVM Virtualization", "Advanced DDoS Protection",
      "Enterprise NVMe SSD Storage", "1 Gbps Network Port", "Unmetered Bandwidth",
      "Full Root Access", "Linux & Windows Support", "Instant Deployment", "Free OS Reinstall",
      "99.9% Uptime Guarantee", "24/7 Premium Support",
    ],
  },
  {
    id: "intel-xeon-vps",
    name: "Intel Xeon VPS",
    tagline: "Premium KVM VPS · Xeon Platinum & E5",
    cpuLabel: "Intel Xeon Enterprise",
    node: "India",
    storageUnit: "NVMe SSD",
    plans: [
      { id: "xs", name: "XS", price: 329, specs: [{ label: "CPU", value: "2 vCores" }, { label: "RAM", value: "6 GB DDR4 ECC" }, { label: "Storage", value: "50 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "s", name: "S", price: 449, specs: [{ label: "CPU", value: "2 vCores" }, { label: "RAM", value: "8 GB DDR4 ECC" }, { label: "Storage", value: "80 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "m", name: "M", price: 649, specs: [{ label: "CPU", value: "4 vCores" }, { label: "RAM", value: "12 GB DDR4 ECC" }, { label: "Storage", value: "100 GB NVMe" }, { label: "Port", value: "1 Gbps" }], highlight: true },
      { id: "l", name: "L", price: 829, specs: [{ label: "CPU", value: "6 vCores" }, { label: "RAM", value: "16 GB DDR4 ECC" }, { label: "Storage", value: "150 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "xl", name: "XL", price: 1249, specs: [{ label: "CPU", value: "6 vCores" }, { label: "RAM", value: "24 GB DDR4 ECC" }, { label: "Storage", value: "200 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "xxl", name: "XXL", price: 1649, specs: [{ label: "CPU", value: "8 vCores" }, { label: "RAM", value: "32 GB DDR4 ECC" }, { label: "Storage", value: "300 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "2xl", name: "2XL", price: 2029, specs: [{ label: "CPU", value: "10 vCores" }, { label: "RAM", value: "48 GB DDR4 ECC" }, { label: "Storage", value: "350 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
      { id: "3xl", name: "3XL", price: 2699, specs: [{ label: "CPU", value: "12 vCores" }, { label: "RAM", value: "64 GB DDR4 ECC" }, { label: "Storage", value: "400 GB NVMe" }, { label: "Port", value: "1 Gbps" }] },
    ],
    includes: [
      "Intel Xeon Enterprise CPU", "KVM Virtualization", "Advanced DDoS Protection",
      "Enterprise NVMe SSD Storage", "1 Gbps Network Port", "Unmetered Bandwidth",
      "Full Root/Administrator Access", "Linux & Windows Support", "Instant Deployment",
      "Free OS Reinstall", "99.9% Uptime Guarantee", "24/7 Premium Support",
    ],
  },
];

export function getCategory(id: string): Category | undefined {
  return CATEGORIES.find((c) => c.id === id);
}

export function getPlan(categoryId: string, planId: string): Plan | undefined {
  return getCategory(categoryId)?.plans.find((p) => p.id === planId);
}
