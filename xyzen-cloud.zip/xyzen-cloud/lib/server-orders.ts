// ─────────────────────────────────────────────────────────────
// SERVER-SIDE order store, used only by API routes (lib/orders.ts
// is the browser-side version used by pages — they're separate on
// purpose since a serverless function can't read localStorage).
//
// ⚠️ IMPORTANT LIMITATION: Vercel's serverless functions do not
// share memory or disk between invocations. This in-memory map
// will lose data whenever a new function instance spins up —
// which happens often. It works for local development and for
// quick testing, but for anything real you must swap this for a
// database.
//
// ── TO UPGRADE TO SUPABASE (Phase 2) ──
// 1. Create a `orders` table in Supabase matching the ServerOrder type.
// 2. Replace the 3 functions below with supabase-js calls:
//      saveServerOrder   → supabase.from('orders').insert(...)
//      getServerOrder    → supabase.from('orders').select().eq('id', id).single()
//      setServerOrderStatus → supabase.from('orders').update(...).eq('id', id)
// 3. Nothing else in the API routes needs to change.
// ─────────────────────────────────────────────────────────────

export type ServerOrder = {
  id: string;
  categoryName: string;
  planName: string;
  price: number;
  extraOptionLabel?: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  discordUsername: string;
  serverName: string;
  status: "pending" | "approved" | "declined";
  declineReason?: string;
  discordMessageId?: string;
  discordChannelId?: string;
};

// Persisted across invocations only within the same warm function —
// good enough for local dev and short-lived testing.
const g = globalThis as unknown as { __xyzenOrders?: Map<string, ServerOrder> };
if (!g.__xyzenOrders) g.__xyzenOrders = new Map();
const store = g.__xyzenOrders;

export function saveServerOrder(order: ServerOrder) {
  store.set(order.id, order);
}

export function getServerOrder(id: string): ServerOrder | undefined {
  return store.get(id);
}

export function setServerOrderStatus(
  id: string,
  status: "approved" | "declined",
  reason?: string
) {
  const order = store.get(id);
  if (!order) return undefined;
  order.status = status;
  if (reason) order.declineReason = reason;
  store.set(id, order);
  return order;
}
