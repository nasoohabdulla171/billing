// ─────────────────────────────────────────────────────────────
// Email sending.
// Env vars required (set in Vercel, never in code):
//   GMAIL_USER    xyzencloud@gmail.com
//   GMAIL_PASS    a Gmail "App Password" — NOT your normal login
//                 password. Generate one at:
//                 https://myaccount.google.com/apppasswords
//                 (requires 2-Step Verification to be turned on)
// ─────────────────────────────────────────────────────────────

import nodemailer from "nodemailer";

function getTransport() {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_PASS;
  if (!user || !pass) throw new Error("Email is not configured (missing env vars).");

  return nodemailer.createTransport({
    service: "gmail",
    auth: { user, pass },
  });
}

export async function sendApprovalEmail(params: {
  to: string;
  firstName: string;
  username: string;
  planName: string;
  serverName: string;
  orderId: string;
}) {
  const transport = getTransport();
  await transport.sendMail({
    from: `"XYZEN CLOUD" <${process.env.GMAIL_USER}>`,
    to: params.to,
    subject: "XYZEN CLOUD Order Approved",
    html: `
      <div style="font-family:sans-serif;background:#08070C;color:#F1EEFA;padding:32px;border-radius:12px;">
        <h2 style="color:#7C5CFF;">Your order is approved 🎉</h2>
        <p>Hi ${params.firstName},</p>
        <p>Your order <b>${params.orderId}</b> (${params.planName}) for server
        <b>${params.serverName}</b> has been approved and provisioned.</p>
        <p><b>Username:</b> ${params.username}</p>
        <p style="margin-top:24px;">
          <a href="https://panel.xyzencloud.online/" style="background:#7C5CFF;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;">Open Hosting Panel</a>
        </p>
        <p style="margin-top:24px;color:#999;">
          Need help? Join our Discord: <a href="https://discord.gg/NpgkzC97zV" style="color:#7C5CFF;">discord.gg/NpgkzC97zV</a>
        </p>
        <p style="margin-top:24px;">Thank you for choosing XYZEN CLOUD.</p>
      </div>
    `,
  });
}

export async function sendDeclineEmail(params: {
  to: string;
  firstName: string;
  orderId: string;
  reason: string;
}) {
  const transport = getTransport();
  await transport.sendMail({
    from: `"XYZEN CLOUD" <${process.env.GMAIL_USER}>`,
    to: params.to,
    subject: "XYZEN CLOUD Order Declined",
    html: `
      <div style="font-family:sans-serif;background:#08070C;color:#F1EEFA;padding:32px;border-radius:12px;">
        <h2 style="color:#FF5D5D;">Your order was declined</h2>
        <p>Hi ${params.firstName},</p>
        <p>Order <b>${params.orderId}</b> could not be approved.</p>
        <p><b>Reason:</b> ${params.reason}</p>
        <p style="margin-top:24px;">
          If you believe this is a mistake, open a ticket on our Discord and our team will help:
        </p>
        <p><a href="https://discord.gg/NpgkzC97zV" style="color:#7C5CFF;">discord.gg/NpgkzC97zV</a></p>
      </div>
    `,
  });
}
